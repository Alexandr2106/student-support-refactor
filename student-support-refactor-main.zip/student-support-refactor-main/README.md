# Student Support Refactoring Project

Ссылка на репозиторий - https://github.com/Alexandr2106/student-support-refactor.git

## Технологии

- Python 3.9+
- pytest
- pytest-mock

## Установка

## Конфигурация

Файл `config.yaml` определяет тип источника данных:

```yaml
dataSourceType: db 
